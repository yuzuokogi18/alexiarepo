import Home from "./pages/Home"





function App() {

  return (<Home></Home>)
}

export default App

import Title from "../molecules/Title";






function Section2() {
    return (
    <>
        <Title></Title>  
    </>)
}

export default Section2;
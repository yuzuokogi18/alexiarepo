import Grid from "../molecules/Grid";






function Section() {
    return (
    <>
        <Grid></Grid>  
    </>)
}

export default Section;
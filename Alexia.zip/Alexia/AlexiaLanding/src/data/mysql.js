const mysql = {
    products : [
        {
            image: 'xdd.jpeg',
            
        }
    ]
}

export default mysql;